package br.com.amil.predojo.model;

/**
 * Representa o tipo especial de jogadoro world
 * @author Levy
 *
 */
public class WorldPlayer extends Player {
	
	public static final String DEFAULT_WORLD_NAME = "<WORLD>";

	public WorldPlayer(String name) {
		super(name);
	}
	
}