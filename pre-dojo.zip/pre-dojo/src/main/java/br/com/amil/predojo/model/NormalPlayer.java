package br.com.amil.predojo.model;

public class NormalPlayer extends Player {

	
	
	public NormalPlayer(String name) {
		super(name);
	}	
}