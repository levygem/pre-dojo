package br.com.amil.predojo.model;

import java.util.Date;

public class DrownMurder extends Murder {

	public DrownMurder(Player killer, Player victim, Date date) {
		super(killer, victim, date);
	}
}